const { Given, When, Then } = require('@cucumber/cucumber');
const { newGame, newRound, showPattern, check } = require('../../dist/script')




//  Verificar que el sistema valide la selección del jugador contra la secuencia de Simon //


Given('El jugador en partida', async function() {

    await newGame();
});

When('Seleccione un color en el nivel actual', async function() {

    await round.playerPattern;

});


Then('Se valida la selección del jugador, contra la secuencia dada por simon', function() {

    return check();
});



//  Verificar que el sistema reinicie la partida si el jugador falla //



Given('El jugador en partida', async function() {
    await newGame();
});

When('seleccione un color errado en el nivel actual', async function() {
    await steps.innerHTML, game.steps < 10 ? "0" + game.steps : game.steps;
});


Then('Se reinicia la partida al nivel 1.', function() {

    return newRound();

});