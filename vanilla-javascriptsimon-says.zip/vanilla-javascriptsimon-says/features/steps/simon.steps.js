const { Given, When, Then } = require('@cucumber/cucumber');
const { newGame, newRound, showPattern, check } = require('../../dist/script')




// Verificar que Simon muestre un color nuevo al azar //

Given('El jugador en partida', async function() {

    await newGame();
});

When('inicia un nuevo nivel', async function() {

    await newRound();

});


Then('Se muestra un nuevo color al azar', function() {

    return showPattern();
});



// Verificar que simon muestre toda la secuencia de colores hasta el momento //

Given('El jugador en partida', async function() {
    await newGame();
});

When('Aprueba el nivel actual', async function() {
    await check();
});


Then('Se muestra la secuencia de colores que se han generado hasta el momento en orden', function() {

    return newRound().round.pattern();

});


// Scenario:  Verificar que simon muestre el número de nivel en el cual se ecuentra el jugador //

Given('El jugador en partida', async function() {
    await newGame();
});

When('Aprueba el nivel actual', async function() {
    await check();
});


Then('Se muestra el número del nivel actual del jugador', function() {

    return newGame().steps.innerHTML;
});