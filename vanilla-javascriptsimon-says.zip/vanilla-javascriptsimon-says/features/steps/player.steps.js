const { Given, When, Then } = require('@cucumber/cucumber');
const { newGame, reset, Game } = require('../../dist/script')


//  Verificar que el jugador pueda reiniciar manualmente la partida //

Given('El jugador', async function() {

    await Game();

});

When('inicie el juego', async function() {

    await reset.onclick();

});


Then('el juego vuelve a iniciar', function() {

    return newGame();
});


// Verificar que Simon muestre un color nuevo al azar //

Given('El jugador', async function() {

    await Game();

});

When('inicie el juego', async function() {

    await reset.onclick();

});


Then('el juego vuelve a iniciar', function() {

    return newGame();
});